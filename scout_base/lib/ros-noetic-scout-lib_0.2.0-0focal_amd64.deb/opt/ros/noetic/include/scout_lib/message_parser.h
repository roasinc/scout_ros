/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef SCOUT_LIB__MESSAGE_PARSER_H_
#define SCOUT_LIB__MESSAGE_PARSER_H_

#include <string>
#include <iostream>
#include <vector>
#include <cmath>
#include <bitset>

#include "scout_lib/message_type.h"

using namespace std;

enum ParseState
{
  WAIT_FOR_SOF1,
  WAIT_FOR_SOF2,
  WAIT_FOR_FRAME_LEN,
  WAIT_FOR_CMD_TYPE,
  WAIT_FOR_CMD_ID,
  WAIT_FOR_DATA,
  WAIT_FOR_FRAME_ID,
  WAIT_FOR_CHECKSUM
};

class MessageParser
{
public:
  MessageParser(string robot_name, RobotState& robot_state, MotorState& motor_state, DriverState& driver_state,
                LightState& light_state, BatteryState& battery_state);

  virtual ~MessageParser() = default;

  /**
   * \brief Parse the message
   * \param msg Message read through serial communication
   */
  void parse(uint8_t msg);

  /**
   * \brief Parse the robot state message
   * \param buffer Robot state message converted to binary number
   */
  void robotState(vector<uint8_t>& buffer);

  /**
   * \brief Parse the motor state message
   * \param index Index of motor
   * \param buffer Motor state converted to binary number
   */
  void motorState(size_t index, vector<uint8_t>& buffer);

  /**
   * \brief Parse the driver state message
   * \param index Index of driver
   * \param buffer Driver state converted to binary number
   */
  void driverState(size_t index, vector<uint8_t>& buffer);

  /**
   * \brief Parse the light state message
   * \param buffer Light state message converted to binary number
   */
  void lightState(vector<uint8_t>& buffer);

  /**
   * \brief Parse the velocity message
   * \param buffer Velocity state message converted to binary number
   */
  void velocity(vector<uint8_t>& buffer);

  /**
   * \brief Parse the position message
   * \param buffer Position state message converted to binary number
   */
  void position(vector<uint8_t>& buffer);

  /**
   * \brief Parse the battery state message
   * \param buffer Battery state message converted to binary number
   */
  void batteryState(vector<uint8_t>& buffer);

  /// State message related
  RobotState& robot_state_;
  MotorState& motor_state_;
  DriverState& driver_state_;
  LightState& light_state_;
  BatteryState& battery_state_;

  // Estop state
  bool estop_state_;

  /// Robot parametres
  string robot_name_;
  double wheel_radius_, wheel_separation_;

private:
  /// Feedback message
  vector<uint8_t> feedback_;
  int8_t data_cnt_;
  uint8_t frame_len_, cmd_id_;

  /// Parse state
  ParseState parse_state_;
};

#endif  // SCOUT_LIB__MESSAGE_PARSER_H_
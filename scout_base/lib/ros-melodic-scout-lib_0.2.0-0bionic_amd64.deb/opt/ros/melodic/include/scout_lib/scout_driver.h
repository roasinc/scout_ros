/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@roas.co.kr>

Copyright (c) 2020, ROAS Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef SCOUT_LIB__SCOUT_DRIVER_H_
#define SCOUT_LIB__SCOUT_DRIVER_H_

#include <string>
#include <iostream>
#include <vector>
#include <mutex>
#include <cmath>
#include <thread>

#include "ros/ros.h"
#include "scout_serial/serial.h"
#include "scout_lib/message_type.h"
#include "scout_lib/message_parser.h"

using namespace std;

class ScoutDriver : public MessageParser
{
public:
  ScoutDriver(string robot, string port, int32_t baud, RobotFeedback& robot_feedback, MotorFeedback& motor_feedback,
              DriverFeedback& driver_feedback, LightFeedback& light_feedback, BatteryFeedback& battery_feedback);

  virtual ~ScoutDriver();

  /**
   * \brief Initialize
   */
  bool init();

  /**
   * \brief Initial setting for serial communication
   */
  bool connect();

  /**
   * \brief Read message
   */
  void read();

  /**
   * \brief Convert the velocity command
   * \param linear  Linear velocity
   * \param angular Angular velocity
   */
  void writeSpeed(const double linear, const double angular);

  /**
   * \brief Send the motor command
   * \param cmd Motor command message for each motors (rad)
   */
  void sendMotorCommand(const MotorCommand& cmd);

  /**
   * \brief Send the light command
   * \param cmd Light command message
   */
  void sendLightCommand(const LightCommand& cmd);

  /**
   * \brief Clearing failure protection
   */
  void clearFailure();

  /**
   * \brief Counting the frame id bit
   */
  void countFrameID();

private:
  /// Class for serial communication
  serial::Serial serial_;

  /// Serial parameters
  string port_;
  int32_t baud_;

  /// Command messages
  uint8_t enable_[8], clear_[8], control_[13], light_[13];

  /// Count of command message
  uint8_t cmd_cnt_;

  /// To receive the message without interruption
  mutex mutex_;
};

#endif  // SCOUT_LIB__SCOUT_DRIVER_H_